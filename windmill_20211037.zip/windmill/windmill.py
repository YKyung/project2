import pygame
import math
import sys
from os import path
import numpy as np

pygame.init()
screen = pygame.display.set_mode((800, 800))
pygame.display.set_caption("windmill_20211037")
clock = pygame.time.Clock()
img_dir = path.join(path.dirname(__file__),)
DEFAULT_IMAGE_SIZE = (800, 800)
DIS = (40,170)

#WINDOW_WIDTH = 800
#WINDOW_HEIGHT = 800

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
PINK = (255, 200, 180)
YELLOW = (255, 255, 0)
PINK1 = (255,170,203)
PURPLE=(162,25,255)


info = pygame.display.Info()

background = pygame.image.load(path.join(img_dir, "land.jpg")).convert()
background = pygame.transform.scale(background, DEFAULT_IMAGE_SIZE)
background_rect = background.get_rect()
person = pygame.image.load(path.join(img_dir, "person.png"))
person = pygame.transform.scale(person, DIS)



# 게임 화면 업데이트 속도
clock = pygame.time.Clock()

degree = 30
done = False
# 폰트 선택(폰트, 크기, 두껍게, 이탤릭)
#font = pygame.font.SysFont('FixedSys', 40, True, False)

poly = np.array( [[200, 250], [200, 200], [230, 200]])
poly1 = np.array( [[200, 250], [250, 250], [250, 280]])
poly2 = np.array( [[200, 250], [200,300], [170, 300]])
poly3 = np.array( [[200, 250], [150, 250], [150, 220]])

Poly = np.array( [[400, 200], [400, 100], [450, 100]])
Poly1 = np.array( [[400, 200], [500, 200], [500, 250]])
Poly2 = np.array( [[400, 200], [400,300], [350, 300]])
Poly3 = np.array( [[400, 200], [300, 200], [300, 150]])

while not done:
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
            done = True
            
    screen.fill(WHITE)
    screen.blit(background, background_rect)
    screen.blit(person, (700,600))
    degree += 1
    radian = np.deg2rad(degree)
    c = np.cos(radian)
    s = np.sin(radian)
    R = np.array( [[ c, -s], [s, c] ] )
    #R, R.shape
    ppT = R @ poly.T 
    pp1T = R @ poly1.T
    pp2T = R @ poly2.T
    pp3T = R @ poly3.T
    pp = ppT.T
    pp1 = pp1T.T
    pp2 = pp2T.T
    pp3 = pp3T.T
    PpT = R @ Poly.T 
    Pp1T = R @ Poly1.T
    Pp2T = R @ Poly2.T
    Pp3T = R @ Poly3.T
    Pp = PpT.T
    Pp1 = Pp1T.T
    Pp2 = Pp2T.T
    Pp3 = Pp3T.T
    
    cor = np.array( [200, 250] )
    pcopy = poly.copy()
    for i in range(pcopy.shape[0]): 
        pcopy[i] = pcopy[i] - cor 
    protated = (R @ pcopy.T).T      
    for i in range(protated.shape[0]): 
        protated[i] = protated[i] + cor 
        
    pcopy1 = poly1.copy()
    for i in range(pcopy1.shape[0]): 
        pcopy1[i] = pcopy1[i] - cor 
    protated1 = (R @ pcopy1.T).T      
    for i in range(protated1.shape[0]): 
        protated1[i] = protated1[i] + cor
    
    pcopy2 = poly2.copy()
    for i in range(pcopy2.shape[0]): 
        pcopy2[i] = pcopy2[i] - cor 
    protated2 = (R @ pcopy2.T).T      
    for i in range(protated2.shape[0]): 
        protated2[i] = protated2[i] + cor   
    
    pcopy3 = poly3.copy()
    for i in range(pcopy3.shape[0]): 
        pcopy3[i] = pcopy3[i] - cor 
    protated3 = (R @ pcopy3.T).T      
    for i in range(protated3.shape[0]): 
        protated3[i] = protated3[i] + cor 
    pygame.draw.polygon(screen,BLUE,[(200,250),(150,470),(250,470)],0)
    pygame.draw.polygon(screen, YELLOW, protated, 0)
    pygame.draw.polygon(screen, YELLOW, protated1, 0)
    pygame.draw.polygon(screen, YELLOW, protated2, 0)
    pygame.draw.polygon(screen, YELLOW, protated3, 0)
    pygame.draw.polygon(screen, GREEN, protated, 1)
    pygame.draw.polygon(screen, GREEN, protated1, 1)
    pygame.draw.polygon(screen, GREEN, protated2, 1)
    pygame.draw.polygon(screen, GREEN, protated3, 1)
    
    cor1 = np.array( [400, 200] )
    pcopy = Poly.copy()
    for i in range(pcopy.shape[0]): 
        pcopy[i] = pcopy[i] - cor1 
    protated = (R @ pcopy.T).T      
    for i in range(protated.shape[0]): 
        protated[i] = protated[i] + cor1 
        
    pcopy1 = Poly1.copy()
    for i in range(pcopy1.shape[0]): 
        pcopy1[i] = pcopy1[i] - cor1 
    protated1 = (R @ pcopy1.T).T      
    for i in range(protated1.shape[0]): 
        protated1[i] = protated1[i] + cor1
    
    pcopy2 = Poly2.copy()
    for i in range(pcopy2.shape[0]): 
        pcopy2[i] = pcopy2[i] - cor1 
    protated2 = (R @ pcopy2.T).T      
    for i in range(protated2.shape[0]): 
        protated2[i] = protated2[i] + cor1   
    
    pcopy3 = Poly3.copy()
    for i in range(pcopy3.shape[0]): 
        pcopy3[i] = pcopy3[i] - cor1 
    protated3 = (R @ pcopy3.T).T      
    for i in range(protated3.shape[0]): 
        protated3[i] = protated3[i] + cor1
    
    pygame.draw.polygon(screen,PURPLE,[(400,200),(450,465),(350,465)],0)
    pygame.draw.polygon(screen, PINK, protated, 0)
    pygame.draw.polygon(screen, PINK, protated1, 0)
    pygame.draw.polygon(screen, PINK, protated2, 0)
    pygame.draw.polygon(screen, PINK, protated3, 0)
    pygame.draw.polygon(screen, PINK1, protated, 4)
    pygame.draw.polygon(screen, PINK1, protated1, 4)
    pygame.draw.polygon(screen, PINK1, protated2, 4)
    pygame.draw.polygon(screen, PINK1, protated3, 4)
    
    
    pygame.display.flip()
    clock.tick(60)
    
pygame.quit()