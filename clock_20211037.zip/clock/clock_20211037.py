import pygame
import math
import sys
from os import path
import numpy as np
import datetime

pygame.init()
screen = pygame.display.set_mode((800, 800))
pygame.display.set_caption("CLOCK_20211037")
clock = pygame.time.Clock()
img_dir = path.join(path.dirname(__file__), )
DEFAULT_IMAGE_SIZE = (800, 800)
now = datetime.datetime.now()

h,m,s = now.hour, now.minute, now.second
h_degree = h*30+(30/60)*m
m_degree = m*6
s_degree = s*6

background = pygame.image.load(path.join(img_dir, "clock.png")).convert()
background = pygame.transform.scale(background, DEFAULT_IMAGE_SIZE)
background_rect = background.get_rect()

degree = 0
poly = np.array( [[400, 200],[400,270],[400,150]])

while(True):
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
    s_degree += 6
    m_degree += 6/60
    h_degree += 6/3600
    #radian = np.deg2rad(degree)
    radian = np.deg2rad(h_degree)
    c = np.cos(radian)
    s = np.sin(radian)
    R = np.array( [[ c, -s], [s, c] ] )
    #R, R.shape
    ppT = R @ poly.T 
    pp = ppT.T
    
    cor = np.array( [ 400, 400] )
    pcopy = poly.copy()
    for i in range(pcopy.shape[0]): # 1. translation to the origin
        pcopy[i] = pcopy[i] - cor 
    protated = (R @ pcopy.T).T      # 2. rotation 
    # 3. translation back 
    for i in range(protated.shape[0]): # 3. translation, back to origignal location
        protated[i] = protated[i] + cor
    screen.fill((0,0,0))
    screen.blit(background, background_rect)
    pygame.draw.line(screen, (0,0,0), cor, protated[1],15)
    radian = np.deg2rad(m_degree)
    c = np.cos(radian)
    s = np.sin(radian)
    R = np.array( [[ c, -s], [s, c] ] )
    #R, R.shape
    ppT = R @ poly.T 
    pp = ppT.T
    
    cor = np.array( [ 400, 400] )
    pcopy = poly.copy()
    for i in range(pcopy.shape[0]): # 1. translation to the origin
        pcopy[i] = pcopy[i] - cor 
    protated = (R @ pcopy.T).T      # 2. rotation 
    # 3. translation back 
    for i in range(protated.shape[0]): # 3. translation, back to origignal location
        protated[i] = protated[i] + cor
    pygame.draw.line(screen, (0,0,0), cor, protated[0],10)
    radian = np.deg2rad(s_degree)
    c = np.cos(radian)
    s = np.sin(radian)
    R = np.array( [[ c, -s], [s, c] ] )
    #R, R.shape
    ppT = R @ poly.T 
    pp = ppT.T
    
    cor = np.array( [ 400, 400] )
    pcopy = poly.copy()
    for i in range(pcopy.shape[0]): # 1. translation to the origin
        pcopy[i] = pcopy[i] - cor 
    protated = (R @ pcopy.T).T      # 2. rotation 
    # 3. translation back 
    for i in range(protated.shape[0]): # 3. translation, back to origignal location
        protated[i] = protated[i] + cor
    pygame.draw.line(screen, (0,0,0), cor, protated[2],5)
    pygame.draw.circle(screen, (0,0,255),[400,400],11,0)
    pygame.display.flip()
    clock.tick(1)